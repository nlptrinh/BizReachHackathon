# BizReachHackathon

How to run:
```
pip install -r requirements.txt
export FLASK_APP=website.py
python -m flask run
```

PowerShell (Windows):
```
$env:FLASK_APP = "website.py"
python -m flask run
```